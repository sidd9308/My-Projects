from tkinter import *
from tkinter import filedialog

root = Tk()
root.title('siddharth live preveiw')
root.iconbitmap('https://th.bing.com/th/id/OIP.GbzTRHVGkpsdhXboa9ymqAHaD7?w=317&h=180&c=7&r=0&o=5&pid=1.7')
root.geometry("500x600")
